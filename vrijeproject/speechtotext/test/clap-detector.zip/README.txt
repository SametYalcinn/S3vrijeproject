A Pen created at CodePen.io. You can find this one at https://codepen.io/wernight/pen/qPRKyG.

 Based on https://gist.github.com/pachacamac/d7b3d667ecaa0cd39f36